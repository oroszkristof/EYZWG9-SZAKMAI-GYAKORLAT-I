INSERT INTO foglalasok (felhasznalok_id, idopontok_id, allapot, megjegyzes)
VALUES
(1, 1, 'lefoglalt', 'Foglalás első próbára.'),
(2, 2, 'teljesitve', 'Már lezajlott.'),
(1, 3, 'lemondva', 'Időpont nem volt megfelelő.'),
(2, 4, 'lefoglalt', 'Sürgős esetre.'),
(1, 5, 'lefoglalt', NULL);
